# TikTok Glass — Android starter

A Kotlin + Jetpack Compose starter for a dark glassmorphism short-video interface.

## Current starter features
- Dark glass-style UI with translucent panels and ambient color haze
- Animated navigation transitions
- Demo vertical feed interaction (swipe up/down to change demo cards)
- Like animation and profile/settings screens
- GitHub Actions workflow that builds a debug APK

## Important status note
This is a UI starter, not a functioning TikTok client. The feed currently uses decorative demo backgrounds rather than real TikTok videos. TikTok's public developer APIs do not automatically provide the complete For You feed or all app actions. Real content, login, likes, comments, and profiles require supported authorization and API access. Do not put private API keys or account credentials into the source code.

The uploaded original APK is not included in this source ZIP. This project does not patch, re-sign, or redistribute the official TikTok app.

## Build with GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root.
3. Open **Actions** and run **Build TikTok Glass APK**, or push to `main`.
4. Download the `tiktok-glass-debug-apk` artifact from the workflow run.

## Build locally
Requires JDK 17, Android SDK platform 35, and Gradle 8.9 or compatible:
```bash
gradle assembleDebug
```
APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Next development steps
1. Add a real Media3 player and a licensed/authorized list of video URLs.
2. Add a backend or supported API integration for content and user state.
3. Replace demo feed state with paging from that data source.
4. Add tests and release signing only after the app behavior is ready.
