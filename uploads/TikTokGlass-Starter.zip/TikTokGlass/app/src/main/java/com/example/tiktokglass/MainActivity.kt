package com.example.tiktokglass

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Night = Color(0xFF07080D)
private val Panel = Color(0xB8171A24)
private val Line = Color(0x40FFFFFF)
private val Pink = Color(0xFFFF3D72)
private val Cyan = Color(0xFF61E8F7)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.BLACK
        window.decorView.systemUiVisibility =
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
        setContent { TikTokGlassApp() }
    }
}

private enum class Screen { Feed, Discover, Inbox, Profile, Settings }

@Composable
private fun TikTokGlassApp() {
    var screen by remember { mutableStateOf(Screen.Feed) }
    var settingsOpen by remember { mutableStateOf(false) }
    BackHandler(enabled = settingsOpen || screen != Screen.Feed) {
        if (settingsOpen) settingsOpen = false else screen = Screen.Feed
    }

    MaterialTheme(colorScheme = darkColorScheme(
        background = Night,
        surface = Panel,
        primary = Pink,
        secondary = Cyan,
        onBackground = Color.White,
        onSurface = Color.White
    )) {
        Box(Modifier.fillMaxSize().background(Night)) {
            // Ambient color haze behind translucent panels.
            Box(Modifier.offset(x = (-100).dp, y = 100.dp).size(250.dp)
                .blur(90.dp).background(Pink.copy(alpha = .20f), CircleShape))
            Box(Modifier.align(Alignment.BottomEnd).offset(x = 80.dp, y = (-90).dp)
                .size(260.dp).blur(100.dp).background(Cyan.copy(alpha = .15f), CircleShape))

            AnimatedContent(
                targetState = screen,
                transitionSpec = {
                    (fadeIn() + slideInHorizontally { it / 12 }) togetherWith
                        (fadeOut() + slideOutHorizontally { -it / 12 })
                },
                label = "screen-transition"
            ) { target ->
                when (target) {
                    Screen.Feed -> FeedScreen(onProfile = { screen = Screen.Profile })
                    Screen.Discover -> SimpleScreen("Discover", "Explore creators and topics", Icons.Default.Search)
                    Screen.Inbox -> SimpleScreen("Inbox", "Your conversations will appear here", Icons.Default.Forum)
                    Screen.Profile -> ProfileScreen(onSettings = { settingsOpen = true })
                    Screen.Settings -> SettingsScreen()
                }
            }

            if (screen != Screen.Settings) {
                GlassBottomBar(
                    selected = screen,
                    onSelect = { screen = it },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 14.dp, vertical = 12.dp)
                )
            }

            AnimatedVisibility(
                visible = settingsOpen,
                enter = fadeIn() + slideInHorizontally { it / 2 },
                exit = fadeOut() + slideOutHorizontally { it / 2 },
                modifier = Modifier.fillMaxSize()
            ) {
                SettingsSheet(onClose = { settingsOpen = false })
            }
        }
    }
}

@Composable
private fun FeedScreen(onProfile: () -> Unit) {
    var index by remember { mutableIntStateOf(0) }
    var liked by remember { mutableStateOf(false) }
    var playing by remember { mutableStateOf(true) }
    val scale by animateFloatAsState(if (liked) 1.22f else 1f, spring(), label = "like-scale")

    val backgrounds = listOf(
        listOf(Color(0xFF152A48), Color(0xFF8B4778), Color(0xFFEF9D8A)),
        listOf(Color(0xFF082F32), Color(0xFF287D78), Color(0xFFB6D9BD)),
        listOf(Color(0xFF2D174C), Color(0xFF6B3F91), Color(0xFFE1A2D4))
    )
    val creators = listOf("@midnight.motion", "@slowdays", "@neon.frames")
    val captions = listOf(
        "little moments, cinematic feelings ✦",
        "a quiet corner of the internet",
        "colors after dark. #visuals"
    )
    val colors = backgrounds[index % backgrounds.size]

    Box(
        Modifier.fillMaxSize()
            .pointerInput(index) {
                var distance = 0f
                detectVerticalDragGestures(
                    onVerticalDrag = { _, drag -> distance += drag },
                    onDragEnd = {
                        if (distance < -55) { index = (index + 1) % 3; liked = false }
                        if (distance > 55) { index = (index + 2) % 3; liked = false }
                        distance = 0f
                    }
                )
            }
            .background(Brush.linearGradient(colors))
            .clickable { playing = !playing }
    ) {
        // Decorative video-like motion backdrop; replace with real authorized media sources.
        Box(Modifier.fillMaxSize().background(
            Brush.radialGradient(listOf(Color.White.copy(.12f), Color.Transparent), radius = 700f)
        ))
        Box(Modifier.align(Alignment.Center).fillMaxWidth(.82f).height(390.dp)
            .clip(RoundedCornerShape(34.dp))
            .background(Brush.linearGradient(listOf(colors[0].copy(.12f), colors[2].copy(.38f), colors[1].copy(.2f))))
            .border(1.dp, Color.White.copy(.12f), RoundedCornerShape(34.dp)))
        Box(Modifier.align(Alignment.Center).size(140.dp).blur(45.dp)
            .background(Cyan.copy(alpha = .24f), CircleShape))
        if (!playing) {
            Icon(Icons.Default.PlayArrow, null, tint = Color.White.copy(.85f),
                modifier = Modifier.align(Alignment.Center).size(64.dp))
        }

        Row(
            Modifier.fillMaxWidth().align(Alignment.TopCenter)
                .statusBarsPadding().padding(horizontal = 20.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text("Following", color = Color.White.copy(.58f), fontSize = 14.sp)
            Spacer(Modifier.width(18.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("For You", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Spacer(Modifier.height(5.dp))
                Box(Modifier.width(25.dp).height(3.dp).clip(CircleShape).background(Pink))
            }
            Spacer(Modifier.weight(1f))
            GlassIconButton(Icons.Default.Search, "Search", onClick = { })
        }

        Column(
            Modifier.align(Alignment.BottomStart).fillMaxWidth(.78f)
                .padding(start = 20.dp, end = 10.dp, bottom = 106.dp)
        ) {
            GlassPill("GLASS FEED  ·  DEMO")
            Spacer(Modifier.height(12.dp))
            Text(creators[index], fontWeight = FontWeight.Bold, fontSize = 17.sp, color = Color.White)
            Spacer(Modifier.height(6.dp))
            Text(captions[index], fontSize = 14.sp, color = Color.White.copy(.9f), maxLines = 2)
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Original audio · Glass Studio", fontSize = 12.sp, color = Color.White.copy(.8f))
            }
        }

        Column(
            Modifier.align(Alignment.BottomEnd).padding(end = 15.dp, bottom = 112.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                Modifier.size(48.dp).clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Pink, Cyan)))
                    .border(2.dp, Color.White.copy(.9f), CircleShape)
                    .clickable(onClick = onProfile),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.height(20.dp))
            Column(horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.clickable { liked = !liked }) {
                Icon(Icons.Default.Favorite, null, tint = if (liked) Pink else Color.White,
                    modifier = Modifier.size(30.dp).scale(scale))
                Text(if (liked) "12.5K" else "12.4K", fontSize = 11.sp, color = Color.White)
            }
            Spacer(Modifier.height(20.dp))
            ActionIcon(Icons.Default.ChatBubble, "328") {}
            Spacer(Modifier.height(20.dp))
            ActionIcon(Icons.Default.Share, "Share") {}
            Spacer(Modifier.height(22.dp))
            Box(Modifier.size(42.dp).clip(CircleShape).background(Panel)
                .border(1.dp, Line, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.Album, null, tint = Color.White)
            }
        }
    }
}

@Composable
private fun GlassBottomBar(selected: Screen, onSelect: (Screen) -> Unit, modifier: Modifier = Modifier) {
    val items = listOf(
        Triple(Screen.Feed, Icons.Default.Home, "Home"),
        Triple(Screen.Discover, Icons.Default.Search, "Discover"),
        Triple(Screen.Inbox, Icons.Default.Forum, "Inbox"),
        Triple(Screen.Profile, Icons.Default.Person, "Profile")
    )
    Row(
        modifier.fillMaxWidth().height(66.dp).clip(RoundedCornerShape(25.dp))
            .background(Brush.verticalGradient(listOf(Color(0xD91C202B), Color(0xC20C0E15))))
            .border(1.dp, Color.White.copy(.16f), RoundedCornerShape(25.dp))
            .padding(horizontal = 8.dp, vertical = 7.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        items.forEach { (destination, icon, label) ->
            val active = selected == destination
            Column(
                Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(17.dp))
                    .background(if (active) Color.White.copy(.10f) else Color.Transparent)
                    .clickable { onSelect(destination) },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(icon, null, tint = if (active) Color.White else Color.White.copy(.55f),
                    modifier = Modifier.size(21.dp))
                Spacer(Modifier.height(3.dp))
                Text(label, fontSize = 10.sp, color = if (active) Color.White else Color.White.copy(.55f))
            }
        }
    }
}

@Composable
private fun GlassIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).background(Panel)
        .border(1.dp, Line, CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, label, tint = Color.White, modifier = Modifier.size(21.dp))
    }
}

@Composable
private fun ActionIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable(onClick = onClick)) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(3.dp))
        Text(label, fontSize = 11.sp, color = Color.White)
    }
}

@Composable
private fun GlassPill(text: String) {
    Text(text, fontSize = 9.sp, letterSpacing = 1.1.sp, fontWeight = FontWeight.SemiBold,
        color = Color.White.copy(.92f),
        modifier = Modifier.clip(CircleShape).background(Color.Black.copy(.25f))
            .border(1.dp, Line, CircleShape).padding(horizontal = 11.dp, vertical = 7.dp))
}

@Composable
private fun ProfileScreen(onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp).statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.End) {
            GlassIconButton(Icons.Default.Settings, "Settings", onSettings)
        }
        Spacer(Modifier.height(35.dp))
        Box(Modifier.align(Alignment.CenterHorizontally).size(92.dp).clip(CircleShape)
            .background(Brush.linearGradient(listOf(Pink, Cyan))), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, tint = Color.White, modifier = Modifier.size(48.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("@your.glass", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White,
            modifier = Modifier.align(Alignment.CenterHorizontally))
        Text("Your profile, reimagined.", color = Color.White.copy(.58f), fontSize = 13.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(top = 6.dp))
        Spacer(Modifier.height(24.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Stat("Following", "128")
            Stat("Followers", "2.4K")
            Stat("Likes", "18.6K")
        }
        Spacer(Modifier.height(30.dp))
        GlassCard {
            Text("Your videos", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Spacer(Modifier.height(8.dp))
            Text("Connect a supported source or add your own media to populate this area.",
                fontSize = 13.sp, color = Color.White.copy(.6f))
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Text(label, fontSize = 11.sp, color = Color.White.copy(.58f))
    }
}

@Composable
private fun SimpleScreen(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 22.dp)) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White,
            modifier = Modifier.padding(top = 24.dp, bottom = 24.dp))
        GlassCard {
            Icon(icon, null, tint = Cyan, modifier = Modifier.size(32.dp))
            Spacer(Modifier.height(14.dp))
            Text(subtitle, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Text("This starter screen is ready for supported API integration.",
                color = Color.White.copy(.58f), fontSize = 13.sp)
        }
    }
}

@Composable
private fun SettingsScreen() {
    Column(Modifier.fillMaxSize().statusBarsPadding().padding(22.dp)) {
        Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color.White)
        Spacer(Modifier.height(18.dp))
        SettingsContent()
    }
}

@Composable
private fun SettingsSheet(onClose: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black.copy(.62f)).clickable(onClick = onClose),
        contentAlignment = Alignment.BottomCenter) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
                .background(Brush.verticalGradient(listOf(Color(0xF0262A37), Color(0xF10C0E15))))
                .border(1.dp, Line, RoundedCornerShape(topStart = 30.dp, topEnd = 30.dp))
                .clickable(enabled = false) {}.padding(22.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Settings", fontSize = 23.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.weight(1f))
                GlassIconButton(Icons.Default.Close, "Close settings", onClose)
            }
            Spacer(Modifier.height(20.dp))
            SettingsContent()
            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SettingsContent() {
    var blur by remember { mutableStateOf(true) }
    var animations by remember { mutableStateOf(true) }
    var haptics by remember { mutableStateOf(false) }
    GlassCard {
        SettingToggle("Glass effects", "Translucent panels and glow", blur) { blur = it }
        HorizontalDivider(color = Line, modifier = Modifier.padding(vertical = 12.dp))
        SettingToggle("Smooth transitions", "Animate navigation and controls", animations) { animations = it }
        HorizontalDivider(color = Line, modifier = Modifier.padding(vertical = 12.dp))
        SettingToggle("Haptic feedback", "Subtle touch feedback", haptics) { haptics = it }
    }
    Spacer(Modifier.height(12.dp))
    Text("TikTok integration is not connected in this starter build. Real feed, account, likes, and comments require supported access.",
        color = Color.White.copy(.52f), fontSize = 12.sp, lineHeight = 17.sp)
}

@Composable
private fun SettingToggle(title: String, subtitle: String, checked: Boolean, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(Modifier.height(3.dp))
            Text(subtitle, color = Color.White.copy(.55f), fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChecked)
    }
}

@Composable
private fun GlassCard(content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
            .background(Brush.verticalGradient(listOf(Color(0xB82A2E3B), Color(0xA812141D))))
            .border(1.dp, Color.White.copy(.14f), RoundedCornerShape(24.dp))
            .padding(20.dp),
        content = content
    )
}
